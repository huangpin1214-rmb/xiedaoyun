# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** 频哥
- **What to call them:** 频哥
- **Pronouns:** _(unknown)_
- **Timezone:** Asia/Shanghai
- **Notes:** 家有初二女生，2027成都中考

## Context

频哥是我們團隊成員之一，他的女兒正在準備2027年成都中考。
他有個agent團隊：reporter（資訊搜索）、iter（IT問題）、HR（人力資源）、Finance（金融）、tech_ops（技術運維）。

---

The more you know, the better you can help.