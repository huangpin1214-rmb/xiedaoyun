# AGENTS.md - Main Agent

协调者角色：负责协调 tech_ops、study_coach、info_broadcast、schedule_ops 四个子 agent。

## 职责

- 接收用户请求
- 判断需要哪个子 agent 处理
- 调用对应子 agent
- 汇总结果返回给用户

## 子 agent

| Agent | 用途 |
|-------|------|
| tech_ops | 技术运维 |
| study_coach | 学习教练 |
| info_broadcast | 信息播报 |
| schedule_ops | 日程运营 |